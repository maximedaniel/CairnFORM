from random import *
from driver.StackController import StackController
from driver.Transition import Transition
import json
from pprint import pprint

stack = StackController(ignore=False)
