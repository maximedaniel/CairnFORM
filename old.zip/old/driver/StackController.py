import threading
from RingController import RingController
from LightController import LightController
from MotionController import MotionController


class StackController:

    def __init__(self, ignore=False):
        self.rlock = threading.RLock()
        self.light = LightController()
        self.motion = MotionController(ignore=True)
        self.name = 'CairnFORM_'+ "_".join("{:02x}".format(hat) for hat in MotionController.hats)
        self.rings = []
        for address in range(len(self.motion.maps)):
            self.rings.append(RingController(address, self.rlock, self.light, self.motion))
        self.reset(ignore)
        
    def reset(self, ignore=False):
        for address in range(len(self.rings)):
            print("ignore reset ->", ignore)
            self.rings[address].reset(ignore)
        
    def push(self, instruction):
        self.rings[instruction[0]].push(instruction[1:])
    
    def isEmpty(self):
        for address in range(len(self.rings)):
            if self.rings[address].thread.isAlive():
                    return False
        return True
        
